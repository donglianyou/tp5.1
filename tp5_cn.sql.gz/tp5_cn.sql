-- phpMyAdmin SQL Dump
-- version 4.8.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: 2018-11-19 18:52:29
-- 服务器版本： 5.7.22
-- PHP Version: 7.2.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tp5.cn`
--

-- --------------------------------------------------------

--
-- 表的结构 `zh_article`
--

CREATE TABLE `zh_article` (
  `id` int(11) NOT NULL COMMENT '主键',
  `title_img` varchar(200) NOT NULL COMMENT '标题图片',
  `is_hot` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否热门1是0否',
  `is_top` tinyint(4) NOT NULL DEFAULT '0' COMMENT '是否置顶1是0否',
  `cate_id` int(10) NOT NULL COMMENT '栏目主键',
  `user_id` int(10) NOT NULL COMMENT '用户主键',
  `title` varchar(255) NOT NULL COMMENT '文档标题',
  `content` text NOT NULL COMMENT '文档内容',
  `pv` int(10) NOT NULL DEFAULT '0' COMMENT '阅读量',
  `status` int(4) NOT NULL DEFAULT '1' COMMENT '状态1显示0隐藏',
  `create_time` int(10) NOT NULL COMMENT '创建时间',
  `update_time` int(10) NOT NULL COMMENT '更新时间'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='文档表';

--
-- 转存表中的数据 `zh_article`
--

INSERT INTO `zh_article` (`id`, `title_img`, `is_hot`, `is_top`, `cate_id`, `user_id`, `title`, `content`, `pv`, `status`, `create_time`, `update_time`) VALUES
(1, '20181026\\09f035939296d86d0fc04cbd889e92ba.jpg', 0, 0, 2, 1, '程秋璐律师', '企业法律顾问+律师上门企业法律顾问+律师上门企业法律顾问+律师上门企业法律顾问+律师上门\r\n企业法律顾问+律师上门\r\n企业法律顾问+律师上门企业法律顾问+律师上门企业法律顾问+律师上门企业法律顾问+律师上门企业法律顾问+律师上门\r\n企业法律顾问+律师上门\r\n企业法律顾问+律师上门企业法律顾问+律师上门企业法律顾问+律师上门企业法律顾问+律师上门企业法律顾问+律师上门\r\n企业法律顾问+律师上门\r\n企业法律顾问+律师上门企业法律顾问+律师上门企业法律顾问+律师上门企业法律顾问+律师上门企业法律顾问+律师上门\r\n企业法律顾问+律师上门\r\n企业法律顾问+律师上门企业法律顾问+律师上门企业法律顾问+律师上门企业法律顾问+律师上门企业法律顾问+律师上门\r\n企业法律顾问+律师上门\r\n企业法律顾问+律师上门', 0, 1, 1540541110, 1540541110),
(2, '20181027\\5b3d12f87bebeb1d3d852e8a0eae7402.jpg', 0, 0, 1, 2, 'ssgegesssss哥哥', 'ssgegesssss哥哥ssgessgegesssss哥哥ssgegesssss哥哥ssgegesssss哥哥ssgegesssss哥哥ssgegesssss哥哥ssgegesssss哥哥ssgegesssss哥哥ssgegesssss哥哥ssgegesssss哥哥ssgegesssss哥哥ssgegesssss哥哥ssgegesssss哥哥ssgegesssss哥哥ssgegesssss哥哥ssgegesssss哥哥ssgegesssss哥哥ssgegesssss哥哥ssgegesssss哥哥ssgegesssss哥哥ssgegesssss哥哥ssgegesssss哥哥ssgegesssss哥哥ssgegesssss哥哥ssgegesssss哥哥ssgegesssss哥哥ssgegesssss哥哥ssgegesssss哥哥ssgegesssss哥哥ssgegesssss哥哥ssgegesssss哥哥gesssss哥哥ssgegesssss哥哥', 4, 1, 1540618180, 1540618180),
(3, '20181026\\09f035939296d86d0fc04cbd889e92ba.jpg', 0, 0, 3, 1, '程秋璐律师', '企业法律顾问+律师上门企业法律顾问+律师上门企业法律顾问+律师上门企业法律顾问+律师上门\r\n企业法律顾问+律师上门\r\n企业法律顾问+律师上门', 0, 1, 1540541110, 1540541110),
(4, '20181027\\5b3d12f87bebeb1d3d852e8a0eae7402.jpg', 0, 0, 4, 1, 'ssgegesssss哥哥', 'ssgegesssss哥哥ssgegesssss哥哥ssgessgegesssss哥哥ssgegesssss哥哥ssgegesssss哥哥ssgegesssss哥哥ssgegesssss哥哥ssgegesssss哥哥ssgegesssss哥哥ssgegesssss哥哥ssgegesssss哥哥ssgegesssss哥哥ssgegesssss哥哥ssgegesssss哥哥ssgegesssss哥哥ssgegesssss哥哥ssgegesssss哥哥ssgegesssss哥哥ssgegesssss哥哥ssgegesssss哥哥gesssss哥哥', 6, 1, 1540618180, 1540618180),
(6, '20181026\\09f035939296d86d0fc04cbd889e92ba.jpg', 0, 0, 2, 2, '程秋璐律师', '企业法律顾问+律师上门企业法律顾问+律师上门企业法律顾问+律师上门企业法律顾问+律师上门\r\n企业法律顾问+律师上门\r\n企业法律顾问+律师上门', 0, 1, 1540541110, 1540541110),
(7, '20181027\\5b3d12f87bebeb1d3d852e8a0eae7402.jpg', 0, 0, 3, 3, 'ssgegesssss哥哥', 'ssgegesssss哥哥ssgegesssss哥哥ssgegesssss哥哥', 0, 1, 1540618180, 1540618180),
(8, '20181026\\09f035939296d86d0fc04cbd889e92ba.jpg', 0, 0, 2, 2, '程秋璐律师', '企业法律顾问+律师上门企业法律顾问+律师上门企业法律顾问+律师上门企业法律顾问+律师上门\r\n企业法律顾问+律师上门\r\n企业法律顾问+律师上门', 0, 1, 1540541110, 1540541110),
(9, '20181027\\5b3d12f87bebeb1d3d852e8a0eae7402.jpg', 0, 0, 1, 3, 'ssgegesssss哥哥', 'ssgegesssss哥哥ssgegesssss哥哥ssgegesssss哥哥', 0, 1, 1540618180, 1540618180),
(13, '20181026\\09f035939296d86d0fc04cbd889e92ba.jpg', 0, 0, 3, 3, '程秋璐律师', '企业法律顾问+律师上门企业法律顾问+律师上门企业法律顾问+律师上门企业法律顾问+律师上门\r\n企业法律顾问+律师上门\r\n企业法律顾问+律师上门企业法律顾问+律师上门企业法律顾问+律师上门企业法律顾问+律师上门企业法律顾问+律师上门\r\n企业法律顾问+律师上门\r\n企业法律顾问+律师上门企业法律顾问+律师上门企业法律顾问+律师上门企业法律顾问+律师上门企业法律顾问+律师上门\r\n企业法律顾问+律师上门\r\n企业法律顾问+律师上门企业法律顾问+律师上门企业法律顾问+律师上门企业法律顾问+律师上门企业法律顾问+律师上门\r\n企业法律顾问+律师上门\r\n企业法律顾问+律师上门企业法律顾问+律师上门企业法律顾问+律师上门企业法律顾问+律师上门企业法律顾问+律师上门\r\n企业法律顾问+律师上门\r\n企业法律顾问+律师上门', 0, 1, 1540541110, 1540541110),
(14, '20181027\\5b3d12f87bebeb1d3d852e8a0eae7402.jpg', 0, 0, 4, 3, 'ssgegesssss哥哥', 'ssgegesssss哥哥ssgegesssss哥哥ssgegesssss哥哥', 0, 1, 1540618180, 1540618180),
(15, '20181026\\09f035939296d86d0fc04cbd889e92ba.jpg', 0, 0, 3, 1, '程秋璐律师', '企业法律顾问+律师上门企业法律顾问+律师上门企业法律顾问+律师上门企业法律顾问+律师上门\r\n企业法律顾问+律师上门\r\n企业法律顾问+律师上门企业法律顾问+律师上门企业法律顾问+律师上门企业法律顾问+律师上门企业法律顾问+律师上门\r\n企业法律顾问+律师上门\r\n企业法律顾问+律师上门企业法律顾问+律师上门企业法律顾问+律师上门企业法律顾问+律师上门企业法律顾问+律师上门\r\n企业法律顾问+律师上门\r\n企业法律顾问+律师上门企业法律顾问+律师上门企业法律顾问+律师上门企业法律顾问+律师上门企业法律顾问+律师上门\r\n企业法律顾问+律师上门\r\n企业法律顾问+律师上门', 0, 1, 1540541110, 1540541110),
(16, '20181027\\5b3d12f87bebeb1d3d852e8a0eae7402.jpg', 0, 0, 1, 2, 'ssgegesssss哥哥', 'ssgegesssss哥哥ssgegesssss哥哥ssgegesssss哥哥', 0, 1, 1540618180, 1540618180),
(17, '20181026\\09f035939296d86d0fc04cbd889e92ba.jpg', 0, 0, 4, 3, '程秋璐律师', '企业法律顾问+律师上门企业法律顾问+律师上门企业法律顾问+律师上门企业法律顾问+律师上门\r\n企业法律顾问+律师上门\r\n企业法律顾问+律师上门', 0, 1, 1540541110, 1540541110),
(18, '20181027\\5b3d12f87bebeb1d3d852e8a0eae7402.jpg', 0, 0, 1, 2, 'ssgegesssss哥哥', 'ssgegesssss哥哥ssgegesssss哥哥ssgegesssss哥哥', 0, 1, 1540618180, 1540618180),
(19, '20181026\\09f035939296d86d0fc04cbd889e92ba.jpg', 0, 0, 2, 1, '程秋璐律师', '企业法律顾问+律师上门企业法律顾问+律师上门企业法律顾问+律师上门企业法律顾问+律师上门\r\n企业法律顾问+律师上门\r\n企业法律顾问+律师上门', 0, 1, 1540541110, 1540541110),
(20, '20181027\\5b3d12f87bebeb1d3d852e8a0eae7402.jpg', 0, 0, 1, 1, 'ssgegesssss哥哥', 'ssgegesssss哥哥ssgegesssss哥哥ssgegesssss哥哥', 0, 1, 1540618180, 1540618180),
(28, '20181027\\4569e0a50b0900a1ace99b510959afe0.jpg', 0, 0, 1, 3, 'PHP是世界上最好的语言', '<div style=\"text-align: center;\"><b style=\"font-size: 1rem;\">PHP是世界上最好的语言</b></div><div>PHP是世界上最好<a href=\"http://www.mobanw.com\" title=\"\" target=\"\">的语言PHP是世界上最好的语</a>言PHP是世界上最好的语言PHP是世界上最好的语言PHP是世界上最好的语言<img src=\"http://tp5.cn/uploads/20181026/09f035939296d86d0fc04cbd889e92ba.jpg\" style=\"font-size: 1rem;\" alt=\"test\" align=\"none\"></div><div><br></div>', 32, 1, 1540623321, 1540623321),
(29, '20181119\\db365059e6c928f451cf0c8fbec77204.png', 0, 0, 3, 1, '第二届皮肤病治疗成果展暨患者援助活动', 'ssgege', 4, 1, 1542624694, 1542624694);

-- --------------------------------------------------------

--
-- 表的结构 `zh_article_category`
--

CREATE TABLE `zh_article_category` (
  `id` int(11) NOT NULL COMMENT '主键',
  `user_id` int(11) NOT NULL DEFAULT '0' COMMENT '用户主键',
  `name` varchar(100) NOT NULL COMMENT '栏目名称',
  `sort` int(4) NOT NULL DEFAULT '1' COMMENT '栏目排序',
  `status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '状态1是启用0是禁用',
  `create_time` int(10) NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) NOT NULL DEFAULT '0' COMMENT '更新时间'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='栏目表';

--
-- 转存表中的数据 `zh_article_category`
--

INSERT INTO `zh_article_category` (`id`, `user_id`, `name`, `sort`, `status`, `create_time`, `update_time`) VALUES
(1, 0, 'PHP', 1, 1, 0, 0),
(2, 0, '前端', 5, 1, 0, 0),
(3, 0, 'MYSQL', 0, 1, 0, 0),
(4, 0, 'javascript', 3, 1, 0, 0);

-- --------------------------------------------------------

--
-- 表的结构 `zh_site`
--

CREATE TABLE `zh_site` (
  `id` int(11) NOT NULL COMMENT '主键',
  `name` varchar(255) NOT NULL COMMENT '站点名称',
  `keywords` varchar(200) NOT NULL COMMENT '关键字',
  `is_open` int(11) NOT NULL DEFAULT '1' COMMENT '是否开启1开0关',
  `is_reg` int(11) NOT NULL DEFAULT '1' COMMENT '是否允许注册1是0否',
  `create_time` int(10) NOT NULL COMMENT '创建时间',
  `update_time` int(10) NOT NULL COMMENT '更新时间'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='站点信息表';

-- --------------------------------------------------------

--
-- 表的结构 `zh_user`
--

CREATE TABLE `zh_user` (
  `id` int(4) NOT NULL COMMENT '主键',
  `is_admin` smallint(2) DEFAULT '0' COMMENT '是否是管理员1是0否',
  `name` varchar(100) NOT NULL COMMENT '用户名名称',
  `email` varchar(200) DEFAULT NULL COMMENT '邮箱',
  `mobile` varchar(15) DEFAULT NULL COMMENT '手机',
  `password` char(40) DEFAULT NULL COMMENT '密码',
  `status` int(11) NOT NULL DEFAULT '1' COMMENT '状态1启用0禁用',
  `create_time` int(10) DEFAULT NULL COMMENT '创建时间',
  `update_time` int(10) DEFAULT NULL COMMENT '更新时间'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='用户表';

--
-- 转存表中的数据 `zh_user`
--

INSERT INTO `zh_user` (`id`, `is_admin`, `name`, `email`, `mobile`, `password`, `status`, `create_time`, `update_time`) VALUES
(1, 0, 'dong', '1158624818@qq.com', '13122707159', 'f865b53623b121fd34ee5426c792e5c33af8c227', 1, 1540542230, 1540542230),
(2, 0, 'donglianyou', 'donglianyou@gmail.com', '13100977632', 'f865b53623b121fd34ee5426c792e5c33af8c227', 1, 1540620226, 1540620226),
(3, 0, 'zhangsan', '2741615036@qq.com', '18777653251', 'f865b53623b121fd34ee5426c792e5c33af8c227', 1, 1540620254, 1540620254);

-- --------------------------------------------------------

--
-- 表的结构 `zh_user_comments`
--

CREATE TABLE `zh_user_comments` (
  `id` int(11) NOT NULL COMMENT '主键',
  `user_id` int(11) NOT NULL COMMENT '用户主键',
  `art_id` int(11) NOT NULL COMMENT '文档主键',
  `content` text NOT NULL COMMENT '评论内容',
  `repy_id` int(11) NOT NULL COMMENT '回复ID',
  `status` int(11) NOT NULL COMMENT '状态1显示0隐藏',
  `create_time` int(10) NOT NULL COMMENT '创建时间',
  `update_time` int(10) NOT NULL COMMENT '更新时间'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='用户评论表';

-- --------------------------------------------------------

--
-- 表的结构 `zh_user_fav`
--

CREATE TABLE `zh_user_fav` (
  `id` int(11) NOT NULL COMMENT '主键',
  `user_id` int(11) NOT NULL COMMENT '用户主键',
  `art_id` int(11) NOT NULL COMMENT '文档主键'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='用户收藏表';

--
-- 转存表中的数据 `zh_user_fav`
--

INSERT INTO `zh_user_fav` (`id`, `user_id`, `art_id`) VALUES
(10, 1, 4),
(11, 2, 2);

-- --------------------------------------------------------

--
-- 表的结构 `zh_user_like`
--

CREATE TABLE `zh_user_like` (
  `id` int(11) NOT NULL COMMENT '主键',
  `user_id` int(11) NOT NULL COMMENT '用户主键',
  `art_id` int(11) NOT NULL COMMENT '文档主键'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='用户点赞表';

--
-- Indexes for dumped tables
--

--
-- Indexes for table `zh_article`
--
ALTER TABLE `zh_article`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `zh_article_category`
--
ALTER TABLE `zh_article_category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `zh_site`
--
ALTER TABLE `zh_site`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `zh_user`
--
ALTER TABLE `zh_user`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `zh_user_comments`
--
ALTER TABLE `zh_user_comments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `zh_user_fav`
--
ALTER TABLE `zh_user_fav`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `zh_user_like`
--
ALTER TABLE `zh_user_like`
  ADD PRIMARY KEY (`id`);

--
-- 在导出的表使用AUTO_INCREMENT
--

--
-- 使用表AUTO_INCREMENT `zh_article`
--
ALTER TABLE `zh_article`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键', AUTO_INCREMENT=30;

--
-- 使用表AUTO_INCREMENT `zh_article_category`
--
ALTER TABLE `zh_article_category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键', AUTO_INCREMENT=5;

--
-- 使用表AUTO_INCREMENT `zh_site`
--
ALTER TABLE `zh_site`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键';

--
-- 使用表AUTO_INCREMENT `zh_user`
--
ALTER TABLE `zh_user`
  MODIFY `id` int(4) NOT NULL AUTO_INCREMENT COMMENT '主键', AUTO_INCREMENT=4;

--
-- 使用表AUTO_INCREMENT `zh_user_comments`
--
ALTER TABLE `zh_user_comments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键';

--
-- 使用表AUTO_INCREMENT `zh_user_fav`
--
ALTER TABLE `zh_user_fav`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键', AUTO_INCREMENT=14;

--
-- 使用表AUTO_INCREMENT `zh_user_like`
--
ALTER TABLE `zh_user_like`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键', AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
